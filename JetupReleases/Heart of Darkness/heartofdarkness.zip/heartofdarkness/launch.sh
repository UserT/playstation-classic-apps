#!/bin/sh
source "/var/volatile/project_eris.cfg"
cd "/var/volatile/launchtmp"
chmod +x "rawgl"
echo -n 2 > "/data/power/disable"
HOME="/var/volatile/launchtmp" LD_LIBRARY_PATH="${PROJECT_ERIS_PATH}/lib" SDL_GAMECONTROLLERCONFIG="$(cat ${PROJECT_ERIS_PATH}/etc/boot_menu/gamecontrollerdb.txt)" ./hode --datapath="$(pwd)/gamedata" &> "${RUNTIME_LOG_PATH}/hode.log" 
echo -n 1 > "/data/power/disable"
echo "launch_StockUI" > "/tmp/launchfilecommand"