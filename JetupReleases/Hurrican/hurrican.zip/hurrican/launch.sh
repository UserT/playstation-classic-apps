#!/bin/sh
source "/var/volatile/project_eris.cfg"
cd "/var/volatile/launchtmp"
chmod +x "hurrican"
echo "launch_StockUI" > "/tmp/launchfilecommand"
echo -n 2 > "/data/power/disable"
HOME="/var/volatile/launchtmp" LD_LIBRARY_PATH=`pwd` SDL_GAMECONTROLLERCONFIG="$(cat ${PROJECT_ERIS_PATH}/etc/boot_menu/gamecontrollerdb.txt)" ./Hurrican &> "${RUNTIME_LOG_PATH}/hurrican.log"
echo -n 1 > "/data/power/disable"